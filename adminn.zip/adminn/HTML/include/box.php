<!--Action boxes-->
<div class="container-fluid">
    <div class="quick-actions_homepage">
      <ul class="quick-actions">
        <li class="bg_lb"> <a href="index.php"> <i class="icon-dashboard"></i> <span class="label label-important">20</span> My Dashboard </a> </li>
        <li class="bg_lg span3"> <a href="charts.html"> <i class="icon-signal"></i> Newsletter</a> </li>
        <li class="bg_ly"> <a href="widgets.html"> <i class="icon-inbox"></i><span class="label label-success">101</span> L'avis des clients </a> </li>
        <li class="bg_lo"> <a href="tables.html"> <i class="icon-th"></i> Nos réalisation</a> </li>
        <li class="bg_ls"> <a href="grid.html"> <i class="icon-fullscreen"></i> Nos Partenaires</a> </li>    
      </ul>
    </div>
<!--End-Action boxes-->   