
<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Acceuil</span></a> </li>
    <li> <a href="widgets.html"><i class="icon icon-inbox"></i> <span>Newsletter</span></a> </li>
    <li><a href="tables.html"><i class="icon icon-th"></i> <span>Avis Clients</span></a></li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Nos réalisation</span></a></li>
    <li><a href="grid.html"><i class="icon icon-fullscreen"></i> <span>Nos Partenaire</span></a></li>

  </ul>
</div>
<!--sidebar-menu-->